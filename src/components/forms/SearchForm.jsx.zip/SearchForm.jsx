import React, { forwardRef, useRef } from "react";
import styled from "styled-components";
import { SvgIconFeather } from "../common";

const Wrapper = styled.form`
  .btn-cross {
    position: absolute;
    right: 0;
    background: red;
    opacity: 0;
  }
  input:focus + .btn-cross {
    z-index: 9;
    opacity: 1;
    border: 0 !important;
    background: transparent !important;
    margin: 1px;
    opacity: 1;
  }
`;
const Icon = styled(SvgIconFeather)``;

const SearchForm = forwardRef((props) => {
  const { className = "", onChange, onClick, placeholder = "Search" } = props;

  const ref = useRef(null);

  const emptyInput = () => {
    ref.current.value = "";
    // ref.current.dispatchEvent(new Event("change", { bubbles: true }));
    // ref.current.dispatchEvent(new Event("input", { bubbles: true }));
    // onChange();
    // var event = new Event("change");
    // ref.current.dispatchEvent(event);

    ref.current.onChange();
  };

  return (
    <Wrapper className={`${className}`}>
      <div className="input-group">
        <input ref={ref} onChange={onChange} type="text" className="form-control" placeholder={placeholder} />

        <button onClick={emptyInput} className="btn btn-outline-light btn-cross" type="button">
          <Icon icon="x" />
        </button>

        <div className="input-group-append">
          <button onClick={onClick} className="btn btn-outline-light" type="button">
            <i className="ti-search"></i>
          </button>
        </div>
      </div>
    </Wrapper>
  );
});

export default React.memo(SearchForm);
